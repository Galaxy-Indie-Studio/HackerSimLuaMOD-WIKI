local utilModules = "Modules/Utils/"
local modModules = "Modules/Mods/"

-->UTIL VARIABLES<--
colors = require(utilModules.."colors")
time = require (utilModules.."time")
enums = require(utilModules.."enums")

-->MOD VARIABLES<--
generalFun = require (modModules.."generalFuncs")


hackersim = {}
--[[This is the package for all of the modules that will be used throughout the game!
TODO: 
1. Keep this as organized as possible!
2. Figure a way to allow the players to create mods!]]

utils = {}
utils.colors = colors
utils.time = time
utils.enums = enums

hackersim.utils = utils

-->MODS<--
hackersim.generalFunctions = generalFun


return  hackersim