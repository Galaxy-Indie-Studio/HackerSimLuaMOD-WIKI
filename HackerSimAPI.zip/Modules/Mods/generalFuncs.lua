
generalFunctions = {}

function generalFunctions.getIsWanted(entity)
    --[[NOTE: This function can only be used on the player or any other criminal oppenont!]]
    if entity.tag == enums.tags.entity then
        if entity.type == "LAW" then
            error(errors.incorrectType.."LAW")
        else
            return entity.isWanted
        end
    else
        error(errors.incorrectTag.."Entity")
    end
end

function generalFunctions.setIsWanted(entity, isWanted)
     --[[NOTE: This function can only be used on the player or any other criminal oppenont!]]
    if entity.tag == enums.tags.entity then
        if entity.type == "LAW" then
            error(errors.incorrectType.."LAW")
        else
            if type(isWanted) == "boolean" then
                entity.isWanted = isWanted
                print("Is Wanted: ".. tostring(entity.isWanted))
            else
                error(errors.incorrectVar.. "Boolean")
            end     
        end
    else
        error(errors.incorrectTag.."Entity")
    end
end
function generalFunctions.getWantedLvl(entity)
     --[[NOTE: This function can only be used on the player or any other criminal oppenont!]]
    if entity.tag == enums.tags.entity then
        if entity.type == "LAW" then
            error(errors.incorrectType.."LAW")
        else
            return entity.wantedLvl
        end
    else
        error(errors.incorrectTag.."Entity")
    end
end

function generalFunctions.setWantedLvl(entity, newWantedLvl)
     --[[NOTE: This function can only be used on the player or any other criminal oppenont!]]
    if entity.tag == enums.tags.entity then
        if entity.type == "LAW" then
            error(errors.incorrectType.."LAW")
        else
            if type(newWantedLvl) == "number" then
                entity.wantedLvl = newWantedLvl
                print("New Wanted Level: ".. tostring(entity.wantedLvl))
            else
                error(errors.incorrectVar.."Number")
            end
        end
    else
        error(errors.incorrectTag.."Entity")
    end
end

function generalFunctions.getName(object)
    return object.name
end

function generalFunctions.setName(object, newName)
    if type(newName) == "string" then
        object.name = newName
        print("New Name: "..object.name)
    else
        error(errors.incorrectVar.."String")
    end
end

function generalFunctions.getCurrency(entity)
    return entity.currency
end

function  generalFunctions.setCurrency(entity, newCurrency)
    if type(newCurrency) == "number" then
        entity.currency = newCurrency
        print("New Currency: ".. tostring(entity.currency))        
    else
        error(errors.incorrectVar.."Number")
    end
end

function generalFunctions.getPop(location)
    if location.TAG ~= "LOCATION" then
        error(errors.incorrectTag.."Location")
    else
        return location.population
    end
end

function generalFunctions.setPop(location, newPop)
    if location.TAG ~= "LOCATION" then
        error(errors.incorrectTag.."Location")
    else
        if type(newPop) == "number" then
            location.population = newPop
            print("New Population: ".. tostring(location.population))
        else
            error(errors.incorrectVar.."Number")
        end
    end
end

function generalFunctions.getHackFun(entity)
    if entity.tag == enums.tags.entity then
        if entity.type == enums.types.entity.player then
            return entity.hack
        else
            error(errors.incorrectType.."Player or Crime")
        end
    else
        error(errors.incorrectTag.."Entity")
    end
end

return generalFunctions