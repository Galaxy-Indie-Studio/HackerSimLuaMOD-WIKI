_G.time = {}

local day = 1
local hour = 12 --Time will be starting a noon 
local min = 0 

local gameTime = tostring(hour) .. ":" .. tostring(min)

function time.startTime()
    if min >= 60 then
        hour = hour + 1
        min = 0
        print(hour)
    elseif min <= 0 then
        for i = 0, 60 do
            time.wait(.5)
            min = i
            print(min)
        end
    end
end

function time.wait(seconds)
    local start = os.time()
    repeat until os.time() > start + seconds
end

return time