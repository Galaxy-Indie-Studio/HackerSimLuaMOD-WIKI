colors = {}


colors.gray = {
    r = 54 / 255,
    g = 51/255,
    b = 51/255
}



return colors