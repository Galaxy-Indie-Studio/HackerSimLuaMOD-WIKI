enums = {}

tags = {}
types = {}

entity = {}
locations = {}

types.entity = entity
types.locations = locations

tags.loc = "LOCATION"
tags.entity = "Entity"

entity.player = "PLAYER"
entity.law = "LAW"
entity.crime = "CRIME"

locations.village = "VILLAGE"
locations.town = "TOWN"
locations.city = "CITY"
locations.metro = "METRO"

enums.tags = tags
enums.types = types

return enums